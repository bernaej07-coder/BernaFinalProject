let currentImageIndex = 0;
let dragonImages = [];
let bodyImage; 
let handImage; 
let isWaving = false; 

const FIRE_DRAGON_INDEX = 2; 
const MOUTH_X = 150; 
const MOUTH_Y = 180;

let fire1X, fire1Y;
let fire2X, fire2Y;

let handXOffset = 0;
const HAND_BASE_X = 0; 
const HAND_BASE_Y = 0; 


const BUTTON_AREA_Y = 350;
const BUTTON_HEIGHT = 40;
const BUTTON_WIDTH = 100;
const BUTTON_PADDING = 20;


function preload() {
  dragonImages.push(loadImage('assets/ideasforfinal.png'));
  dragonImages.push(loadImage('assets/talkingdragon.png'));
  dragonImages.push(loadImage('assets/firedragon.png')); 
  
  bodyImage = loadImage('assets/dragonhandbody.png');
  handImage = loadImage('assets/dragonhand.png'); 
}

function setup() {
  createCanvas(400, 400);
  fire1X = MOUTH_X;
  fire1Y = MOUTH_Y;
  fire2X = MOUTH_X + 10;
  fire2Y = MOUTH_Y + 5;
}

function draw() {
  background('purple');

  if (isWaving) {
    image(bodyImage, 0, 0, width, height);
    handXOffset = sin(frameCount * 0.15) * 7; 
    image(handImage, HAND_BASE_X + handXOffset, HAND_BASE_Y, width, height); 

  } else if (currentImageIndex === FIRE_DRAGON_INDEX) {
    image(dragonImages[currentImageIndex], 0, 0, width, height);
    fill(255, 100, 0); 
    noStroke();
    ellipse(fire1X, fire1Y, 30, 30);
    fire1X -= 4;
        if (fire1X < 0) {
      fire1X = MOUTH_X;
      fire1Y = MOUTH_Y;     
    }
  } else {
    image(dragonImages[currentImageIndex], 0, 0, width, height);
  }

  drawButtons();
}

function drawButtons() {
    textAlign(CENTER, CENTER);
    textSize(14);

    let button0X = BUTTON_PADDING;
    fill(currentImageIndex === 0 && !isWaving ? 'cyan' : 'white');
    rect(button0X, BUTTON_AREA_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
    fill('black');
    text('Happy', button0X + BUTTON_WIDTH / 2, BUTTON_AREA_Y + BUTTON_HEIGHT / 2);

    // Button 1 (Talking Dragon)
    let button1X = BUTTON_PADDING + BUTTON_WIDTH + BUTTON_PADDING;
    fill(currentImageIndex === 1 && !isWaving ? 'cyan' : 'white');
    rect(button1X, BUTTON_AREA_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
    fill('black');
    text('Talk', button1X + BUTTON_WIDTH / 2, BUTTON_AREA_Y + BUTTON_HEIGHT / 2);

 
    let button2X = BUTTON_PADDING + (BUTTON_WIDTH + BUTTON_PADDING) * 2;
    fill(currentImageIndex === 2 && !isWaving ? 'cyan' : 'white');
    rect(button2X, BUTTON_AREA_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
    fill('black');
    text('Fire', button2X + BUTTON_WIDTH / 2, BUTTON_AREA_Y + BUTTON_HEIGHT / 2);
    
    let waveButtonX = width - BUTTON_WIDTH - BUTTON_PADDING;
    let waveButtonY = BUTTON_PADDING;
    fill(isWaving ? 'lime' : 'lightgray');
    rect(waveButtonX, waveButtonY, BUTTON_WIDTH, BUTTON_HEIGHT);
    fill('black');
    text('Wave', waveButtonX + BUTTON_WIDTH / 2, waveButtonY + BUTTON_HEIGHT / 2);
}



function mouseClicked() {
  if (mouseY > BUTTON_AREA_Y && mouseY < BUTTON_AREA_Y + BUTTON_HEIGHT) {
    let button0X = BUTTON_PADDING;
    let button1X = BUTTON_PADDING + BUTTON_WIDTH + BUTTON_PADDING;
    let button2X = BUTTON_PADDING + (BUTTON_WIDTH + BUTTON_PADDING) * 2;

    if (mouseX > button0X && mouseX < button0X + BUTTON_WIDTH) {
      currentImageIndex = 0;
      isWaving = false; // Stop waving when selecting an image
    } else if (mouseX > button1X && mouseX < button1X + BUTTON_WIDTH) {
      currentImageIndex = 1;
      isWaving = false; // Stop waving when selecting an image
    } else if (mouseX > button2X && mouseX < button2X + BUTTON_WIDTH) {
      currentImageIndex = 2;
      isWaving = false; // Stop waving when selecting an image
    }
  }
  
  let waveButtonX = width - BUTTON_WIDTH - BUTTON_PADDING;
  let waveButtonY = BUTTON_PADDING;
  if (mouseX > waveButtonX && mouseX < waveButtonX + BUTTON_WIDTH && 
      mouseY > waveButtonY && mouseY < waveButtonY + BUTTON_HEIGHT) {
      isWaving = !isWaving; // Toggle the waving state
  }
}

